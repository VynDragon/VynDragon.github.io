export PATH=$PATH:"/home/vdragon/dev/DUO/boost_1_84_0/Boost.Build/bin"
cd ..
CFLAGS="-march=rv64imafdcv0p7 -mabi=lp64d -mcmodel=medany -mtune=thead-c906" \
CXXFLAGS="-march=rv64imafdcv0p7 -mabi=lp64d -mcmodel=medany -mtune=thead-c906" \
# why do we need yet another random fucking tool with its own special arguments and special settings??? Urr Durr you need to set the settings in the special file in the special format that's not
# aligned with any standard or more common system and is badly documented and have no examples, use something standard or at least wrap it FFS I am tired of learning a new build system every fucking
# time i have to  build a  project
b2 --build-dir=$PWD/build \
toolset=gcc \
--user-config=$PWD/build/user-config.jam \
stage -j16
