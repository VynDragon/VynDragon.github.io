import argparse, mmap, os, sys, struct, hashlib

def auto_int(x):
    return int(x, 0)

parser = argparse.ArgumentParser(
                    prog='to_devmem',
                    description='copy files to devmem address')
parser.add_argument('address', type=auto_int)
parser.add_argument('files', type=argparse.FileType('rb'), default=[], nargs=argparse.REMAINDER)



args = parser.parse_args()
#we use os api, not regular python api
devmem = os.open("/dev/mem", os.O_RDWR | os.O_SYNC)
# just get the entire address space
memory = mmap.mmap(devmem, 0xFFFFFFFF, mmap.MAP_SHARED | mmap.PROT_READ | mmap.PROT_WRITE)

if len(args.files) < 1:
    print("No files provided, we will read 32 bits at address")
    memory.seek(args.address)
    mem = memory.read(4)
    data = struct.unpack("@I", bytearray(mem))
    print(hex(data[0]))
    sys.exit(0)

if len(args.files) == 1:
    the_file = args.files[0]
    print("Writing file " + the_file.name + " at " + hex(args.address))
    the_file.seek(0, os.SEEK_END)
    file_size = the_file.tell()
    print("Size of: " + str(file_size) + " bytes")
    # dont worry, 64 MB > 8KB
    the_file.seek(0)
    data = the_file.read()
    f_hash = hashlib.sha256()
    f_hash.update(data)
    print("File Hash: " + f_hash.hexdigest())
    memory.seek(args.address)
    memory.write(data)

    memory.seek(args.address)
    data_copy = memory.read(file_size)
    d_hash = hashlib.sha256()
    d_hash.update(data_copy)
    print("Memory Copy Hash: " + d_hash.hexdigest())
    if d_hash.digest() != f_hash.digest():
        print("Hash Do not Match")
        print(data)
        print(data_copy)
        sys.exit(1)
    else:
        print("Hashes Match")
    sys.exit(0)

print("Not Implemented")
