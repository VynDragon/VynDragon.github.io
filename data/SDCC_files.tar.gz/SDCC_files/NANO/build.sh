unset LIBRARY_PATH CPATH C_INCLUDE_PATH PKG_CONFIG_PATH CPLUS_INCLUDE_PATH INCLUDE
CFLAGS="-march=rv64imafdcv0p7 -mabi=lp64d -mcmodel=medany -mtune=thead-c906 -static \
-I/home/vdragon/dev/DUO/zlib-1.3.1/build/out/include -I/home/vdragon/dev/DUO/boost_1_84_0/ \
-I/home/vdragon/dev/DUO/ncurses-6.4/build/out/include/ncurses \
-I/home/vdragon/dev/DUO/ncurses-6.4/build/out/include" \
CXXFLAGS="-march=rv64imafdcv0p7 -mabi=lp64d -mcmodel=medany -mtune=thead-c906 -static \
-I/home/vdragon/dev/DUO/zlib-1.3.1/build/out/include -I/home/vdragon/dev/DUO/boost_1_84_0/ -fpermissive \
-I/home/vdragon/dev/DUO/ncurses-6.4/build/out/include/ncurses\
-I/home/vdragon/dev/DUO/ncurses-6.4/build/out/include" \
LDFLAGS="-L/home/vdragon/dev/DUO/zlib-1.3.1/build/out/lib -L/home/vdragon/dev/DUO/boost_1_84_0/stage/lib/ -static \
-L/home/vdragon/dev/DUO/ncurses-6.4/build/out/lib" \
CC=riscv64-unknown-linux-gnu-gcc \
CXX=riscv64-unknown-linux-gnu-g++ \
make -j16
