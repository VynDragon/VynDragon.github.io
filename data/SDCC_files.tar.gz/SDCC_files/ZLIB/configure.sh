cmake -DCMAKE_INSTALL_PREFIX=$PWD/out -DCMAKE_TOOLCHAIN_FILE=/home/vdragon/dev/DUO/toolchain_c906.cmake ..
