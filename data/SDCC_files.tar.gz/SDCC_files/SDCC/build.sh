unset LIBRARY_PATH CPATH C_INCLUDE_PATH PKG_CONFIG_PATH CPLUS_INCLUDE_PATH INCLUDE
CFLAGS="-march=rv64imafdcv0p7 -mabi=lp64d -mcmodel=medany -mtune=thead-c906 -static -I/home/vdragon/dev/DUO/zlib-1.3.1/build/out/include -I/home/vdragon/dev/DUO/boost_1_84_0/ -fpermissive" \
CXXFLAGS="-march=rv64imafdcv0p7 -mabi=lp64d -mcmodel=medany -mtune=thead-c906 -static -I/home/vdragon/dev/DUO/zlib-1.3.1/build/out/include -I/home/vdragon/dev/DUO/boost_1_84_0/ -fpermissive" \
LDFLAGS="-L/home/vdragon/dev/DUO/zlib-1.3.1/build/out/lib -L/home/vdragon/dev/DUO/boost_1_84_0/stage/lib/ -static" \
CC=riscv64-unknown-linux-gnu-gcc \
CXX=riscv64-unknown-linux-gnu-g++ \
make -j16
